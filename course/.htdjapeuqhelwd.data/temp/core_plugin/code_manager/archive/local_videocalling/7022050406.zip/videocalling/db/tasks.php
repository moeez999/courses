<?php
$tasks = [
    [
        'classname' => 'local_videocalling\task\notify_upcoming_sessions',
        'blocking' => 0,
        'minute' => '*',
        'hour' => '*',
        'day' => '*',
        'dayofweek' => '*',
        'month' => '*'
    ],
];