# Changelog

## [1.2.12](https://github.com/mynaparrot/moodle-mod_plugnmeet/compare/v1.2.11...v1.2.12) (2024-11-09)


### Bug Fixes

* **bump:** bump version ([31ab32a](https://github.com/mynaparrot/moodle-mod_plugnmeet/commit/31ab32ad433c0066b864b61eb0eeab7e80d7f631))
* **ci:** added release-please-action ([384a360](https://github.com/mynaparrot/moodle-mod_plugnmeet/commit/384a360acddbcdef4c4743ab5a66aae08ed3e45a))
* **ci:** Crowdin commit ([ffc16b4](https://github.com/mynaparrot/moodle-mod_plugnmeet/commit/ffc16b4a95465af52d720503d10cf3163fcd6593))
* **ci:** Crowdin commit ([52a6238](https://github.com/mynaparrot/moodle-mod_plugnmeet/commit/52a6238a9d9934ca79c9ef5c2dba70b2b4d80cb2))
